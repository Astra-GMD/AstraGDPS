const $ = (s) => document.querySelector(s);
$('#year').textContent = new Date().getFullYear();
async function loadLevels() {
  try {
    const data = await fetch('/api/levels').then(r => r.json());
    const rows = data.levels || [];
    $('#levels-list').innerHTML = rows.length ? rows.map((x,i) =>
      `<div class="data-row"><span class="number">${String(i+1).padStart(2,'0')}</span><div><strong>${escapeHtml(x.name)}</strong><small>by ${escapeHtml(x.creator)}</small></div><span class="pill">${escapeHtml(x.difficulty)}</span></div>`).join('') :
      '<p class="muted">Пока нет уровней. Добавь первый уровень через защищённый API администратора.</p>';
  } catch { $('#levels-list').innerHTML = '<p class="muted">API пока недоступен.</p>'; }
}
async function loadRanks() {
  try {
    const data = await fetch('/api/leaderboard').then(r => r.json());
    const rows = data.leaderboard || [];
    $('#rank-list').innerHTML = rows.length ? rows.map((x,i) =>
      `<div class="data-row"><span class="number">#${i+1}</span><div><strong>${escapeHtml(x.username)}</strong><small>${x.attempts} результатов</small></div><span class="pill">${x.percent}%</span></div>`).join('') :
      '<p class="muted">Рейтинг появится после первых результатов.</p>';
  } catch { $('#rank-list').innerHTML = '<p class="muted">API пока недоступен.</p>'; }
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
$('#register-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const msg = $('#register-msg');
  msg.textContent = 'Создаём аккаунт...';
  try {
    const response = await fetch('/api/register', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({username:form.get('username'), password:form.get('password')})});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Ошибка регистрации');
    msg.textContent = `Аккаунт ${data.user.username} создан. Вход и игровая авторизация ещё не подключены.`;
    event.currentTarget.reset();
  } catch (e) { msg.textContent = e.message || 'Не удалось связаться с сервером.'; }
});
loadLevels(); loadRanks();