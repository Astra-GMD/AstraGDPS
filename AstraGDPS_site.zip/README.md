# AstraGDPS — starter kit

Неоновый русскоязычный портал AstraGDPS + стартовый REST API. Это рабочий каркас сайта и backend, **не полностью совместимый с игровым клиентом Geometry Dash**: для настоящего GDPS нужно реализовать протокол конкретной версии клиента и его игровые endpoints.

## Что есть
- адаптивный неоновый сайт;
- API health-check, регистрация пользователей (bcrypt-хеш пароля), список уровней, таблица лидеров и запись результата;
- базовое ограничение частоты запросов и security headers;
- секретный seed endpoint для добавления тестовых уровней.

## Локальный запуск
Требуется Node.js 20+.
```bash
npm install
npm start
```
Откройте http://localhost:3000

Проверка API:
```bash
curl http://localhost:3000/api/health
curl http://localhost:3000/api/levels
```

Добавить демо-уровень (в отдельном терминале):
```bash
# сначала задайте SEED_KEY в окружении при запуске сервера
curl -X POST http://localhost:3000/api/admin/seed-level \
  -H "Content-Type: application/json" -H "x-seed-key: YOUR_SEED_KEY" \
  -d '{"name":"Neon Ascent","creator":"Astra","difficulty":"Hard"}'
```

## Бесплатное размещение
### Самый простой старт: Render
1. Создайте репозиторий GitHub и загрузите содержимое этой папки.
2. В Render выберите **New → Blueprint** и подключите репозиторий с `render.yaml` (либо создайте Web Service вручную, `npm install` / `npm start`).
3. Откройте выданный URL.

Важно: бесплатные Render Web Services засыпают после 15 минут без трафика, а файловая система эфемерная — SQLite-файл может потеряться при перезапуске/деплое. Бесплатная Render Postgres база ограничена 1 GB и истекает через 30 дней. Поэтому для реальных аккаунтов и уровней перенесите БД на отдельный Postgres с постоянным бесплатным тарифом и замените SQLite-адаптер. Не храните ценные данные на текущем демо-развёртывании.

## Перед публичным запуском
- Добавить сессии/JWT и endpoint входа, email verification, reset password и защиту от перебора.
- Привязать scores к аутентифицированным пользователям; сейчас username в `/api/scores` не подтверждён логином — это только прототип.
- Использовать Postgres, резервные копии, миграции и мониторинг.
- Проверить правила хостинга и права на любые игровые ресурсы. Проект не связан с RobTop Games.
- Не использовать этот API как готовый сервер GDPS. Для полноценной совместимости нужны endpoints и форматы данных под конкретную версию Geometry Dash; также нужно безопасно реализовать загрузку уровней и модерацию.

## API
- `GET /api/health`
- `POST /api/register` body: `{ "username": "Player_1", "password": "at-least-10-chars" }`
- `GET /api/levels`
- `GET /api/leaderboard`
- `POST /api/scores` body: `{ "username": "Player_1", "levelId": 1, "percent": 100 }`
- `POST /api/admin/seed-level` header `x-seed-key: <SEED_KEY>`, body `{ "name": "...", "creator": "...", "difficulty": "Hard" }`
