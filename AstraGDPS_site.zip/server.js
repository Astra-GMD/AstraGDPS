const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;
const db = new Database(process.env.DB_FILE || 'astragdps.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS levels (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 creator TEXT NOT NULL,
 difficulty TEXT NOT NULL DEFAULT 'Normal',
 downloads INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS scores (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 level_id INTEGER NOT NULL,
 percent INTEGER NOT NULL CHECK(percent BETWEEN 0 AND 100),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '32kb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 100, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, name: 'AstraGDPS API', version: 'starter-1.0' }));

app.post('/api/register', rateLimit({ windowMs: 15 * 60_000, limit: 8 }), async (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username))
    return res.status(400).json({ error: 'Ник: 3–20 символов, латиница, цифры и _.' });
  if (password.length < 10 || password.length > 72)
    return res.status(400).json({ error: 'Пароль должен содержать 10–72 символа.' });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)').run(username, hash);
    res.status(201).json({ ok: true, user: { id: result.lastInsertRowid, username } });
  } catch (e) {
    if (String(e.code).includes('SQLITE_CONSTRAINT')) return res.status(409).json({ error: 'Этот ник уже занят.' });
    res.status(500).json({ error: 'Не удалось создать аккаунт.' });
  }
});

app.get('/api/levels', (_req, res) => {
  const levels = db.prepare('SELECT id, name, creator, difficulty, downloads FROM levels ORDER BY id DESC LIMIT 100').all();
  res.json({ levels });
});

// Starter/admin seed endpoint: protect it with SEED_KEY before exposing publicly.
app.post('/api/admin/seed-level', (req, res) => {
  const key = process.env.SEED_KEY;
  if (!key || req.get('x-seed-key') !== key) return res.status(403).json({ error: 'Forbidden' });
  const name = String(req.body.name || '').trim().slice(0, 80);
  const creator = String(req.body.creator || 'AstraGDPS').trim().slice(0, 20);
  const difficulty = String(req.body.difficulty || 'Normal').slice(0, 20);
  if (!name) return res.status(400).json({ error: 'Укажи название уровня.' });
  const result = db.prepare('INSERT INTO levels (name, creator, difficulty) VALUES (?, ?, ?)').run(name, creator, difficulty);
  res.status(201).json({ ok: true, id: result.lastInsertRowid });
});

app.get('/api/leaderboard', (_req, res) => {
  const rows = db.prepare(`
    SELECT username, MAX(percent) AS percent, COUNT(*) AS attempts
    FROM scores GROUP BY username ORDER BY percent DESC, attempts ASC LIMIT 50
  `).all();
  res.json({ leaderboard: rows });
});

app.post('/api/scores', (req, res) => {
  const username = String(req.body.username || '').trim();
  const levelId = Number(req.body.levelId);
  const percent = Number(req.body.percent);
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username) || !Number.isInteger(levelId) ||
      !Number.isInteger(percent) || percent < 0 || percent > 100)
    return res.status(400).json({ error: 'Некорректные данные результата.' });
  const level = db.prepare('SELECT id FROM levels WHERE id = ?').get(levelId);
  if (!level) return res.status(404).json({ error: 'Уровень не найден.' });
  db.prepare('INSERT INTO scores (username, level_id, percent) VALUES (?, ?, ?)').run(username, levelId, percent);
  res.status(201).json({ ok: true });
});

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
app.listen(port, () => console.log(`AstraGDPS running on ${port}`));
